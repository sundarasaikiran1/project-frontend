import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { AdmindrugsComponent } from './admindrugs/admindrugs.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { OrderdetailsComponent } from './orderdetails/orderdetails.component';
import { RestrictGuardGuard } from './restrict-guard.guard';
import { SignupComponent } from './signup/signup.component';
import { SupplierComponent } from './supplier/supplier.component';
import { UsercartComponent } from './usercart/usercart.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"home",component:HomeComponent},
  {path:"about",component:AboutComponent},
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"user",component:UserdashboardComponent
      // children:[{path:"mycart",component:UsercartComponent}]



  },
  {path:"admin",component:AdmindashboardComponent,canActivate:[RestrictGuardGuard]},
  {path:"supplier",component:SupplierComponent,canActivate:[RestrictGuardGuard]},
  {path:"admindrug",component:AdmindrugsComponent,canActivate:[RestrictGuardGuard]},
  {path:"adminorders",component:OrderdetailsComponent,canActivate:[RestrictGuardGuard]},
  
  {path:"**",component:HomeComponent,canActivate:[RestrictGuardGuard]},
  {path:"mycart",component:UsercartComponent}






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
