export interface Supplier{
    supplierId:number;
    supplierName:string;
    supplierEmail:string;
    supplierContact:number;
    
    
}