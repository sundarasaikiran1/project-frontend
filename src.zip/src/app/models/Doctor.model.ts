export interface Doctor{
    userId : number;
    userName :string;
    userAddress :string;
    userContact :number;
    email :string;
    password :string;
    
    
}