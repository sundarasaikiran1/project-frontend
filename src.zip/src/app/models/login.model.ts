export interface Login{
    role:string;
    emailId: string,
  password: string    
}