export interface Drug{
    drugId:number;
    drugName:string;
    quantity:number;
    price:number;
    expiryDate:number;
    supplierId:number;
    
}