import { Component, OnInit } from '@angular/core';
import { Drug } from '../models/drug.model';
import { PharmacyService } from '../service/pharmacy.service';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  public drugs:Drug[]=[];
  drugL:Drug={
    drugId: 0,
    drugName: '',
    quantity: 0,
    price: 0,
    expiryDate:0,
    supplierId: 0
  }
  constructor(private pharmacyService:PharmacyService) { }

  ngOnInit(): void {
    this.getAllDrugs();

  }
  getAllDrugs(){
    this.pharmacyService.getalldrugs()
    .subscribe(
      response=>{
        this.drugs=response;
        console.log(response);
      }

    );
  }
  BookDrug(drugk:Drug){
    this.drugL.drugId=drugk.drugId;
    this.drugL.drugName=drugk.drugName;
    this.drugL.quantity=drugk.quantity;
    this.drugL.price=drugk.price;
    this.drugL.expiryDate=drugk.expiryDate;
    this.drugL.supplierId=drugk.supplierId;
  }

}
