import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Doctor } from '../models/Doctor.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  doctor: Doctor;

  constructor(
    private doctorsignupservice: LoginService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null) form.reset();
    this.doctor = {
    userId: 0,
  userName: "string",
  userAddress: "string",
  userContact: 0,
  email: "string",
  password: "string"
    };
  }

  RedirectToLogin() {
    this.router.navigate(['/login']);
  }

  OnSubmit(form: NgForm) {
    this.doctorsignupservice.registerUser(form.value).subscribe((data: any) => {
      console.log(data);
      if (data) {
        this.resetForm(form);
        this.toastr.success('User registration successful');
        this.RedirectToLogin();
      }
    });
  }
}

