import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login } from '../models/login.model';
import { LoginService } from '../service/login.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: Login ;

  formModel={
    role: "",
    emailId:"",
    password:""
  }
  constructor(private loginService: LoginService,private toastr: ToastrService,private router:Router) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null) form.reset();
    this.login = {
      role:'',
      password: '',
      emailId: '',
    };
  }

  OnSubmit(form: NgForm) {
    console.log(form.value);
    console.log(form.value.role);
    if (form.value.role == 'Doctor') {
      this.loginService
        .LoginDoctor(form.value)
        .subscribe((data: any) => {
          console.log(data);
          this.toastr.success('Doctor Login successful');
          localStorage.setItem('token',data)
          this.router.navigate(['/user']);
        });
    } else if (form.value.role == 'Admin') {
      this.loginService.LoginAdmin(form.value).subscribe((data: any) => {
        console.log(data);
        this.toastr.success('Admin login successful');
        localStorage.setItem('token',data)
        this.router.navigate(['/admin']);
      });
    } else {
      this.toastr.error('Check your Credentials and Role');
    }
  }


}
