import { Component, OnInit } from '@angular/core';
import { Supplier } from '../models/supplier.model';
import { PharmacyService } from '../service/pharmacy.service';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {
  public Suppliers:Supplier[]=[];

  


  constructor(private pharmacyService:PharmacyService) { }

  

  ngOnInit(): void {
    this.getAllSupplier()

  }
  getAllSupplier(){
    this.pharmacyService.getAllSupplierdata()
    .subscribe(
      response=>{
        this.Suppliers=response;
        console.log(response);
      }

    );
  }
  
  supplieradd : Supplier={
    supplierId: 0,
    supplierName: '',
    supplierEmail: '',
    supplierContact:0}

  onSubmit(){
    this.pharmacyService.AddSupplier(this.supplieradd)
    .subscribe(
      Response=>{
        this.getAllSupplier();
        this.pharmacyService.AddSupplier(this.supplieradd);
      }
    )
  }


  DeleteSupplier(id:number){
    this.pharmacyService.deleteSupplier(id)
    .subscribe(
      Response=>{
        this.getAllSupplier();
      }
    );

  }
}
