import { Component, OnInit } from '@angular/core';
import { Drug } from '../models/drug.model';

@Component({
  selector: 'app-usercart',
  templateUrl: './usercart.component.html',
  styleUrls: ['./usercart.component.css']
})
export class UsercartComponent implements OnInit {



  constructor() { }

  ngOnInit(): void {
  }
  

}
