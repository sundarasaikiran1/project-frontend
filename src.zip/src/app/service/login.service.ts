import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Login } from '../models/login.model';
import { Doctor } from '../models/Doctor.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
baseUrl='http://localhost:58778/api/';

  constructor(private http:HttpClient) { }

  LoginAdmin( admin: Login){
    return this.http.post(this.baseUrl+'Login',admin,{responseType:'text'});
  }
  LoginDoctor( doctor: Login){
    return this.http.post(this.baseUrl+'Login',doctor,{responseType:'text'});
  }

  registerUser(doctor:Doctor){
    return this.http.post(this.baseUrl+'User',doctor,{responseType:'text'});
  }

  loggedIn(){
    return !!localStorage.getItem('token')
  }
}




