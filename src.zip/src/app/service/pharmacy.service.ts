import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Drug } from '../models/drug.model';
import { Observable } from 'rxjs';
import { Login } from '../models/login.model';
import { Supplier } from '../models/supplier.model';

@Injectable({
  providedIn: 'root'
})
export class PharmacyService {
  baseUrl='http://localhost:58778/api/';

  constructor(private http:HttpClient) { }



  getalldrugs():Observable<Drug[]>{
    return this.http.get<Drug[]>(this.baseUrl+'Drug');
  }
  AddDrugs(drugL:Drug):Observable<Drug>{
    return this.http.post<Drug>(this.baseUrl+'Drug',drugL);
  }






  getAllSupplierdata():Observable<Supplier[]>{
    return this.http.get<Supplier[]>(this.baseUrl+'Supplier');
  }

  AddSupplier(supplier:Supplier):Observable<Supplier>{
    return this.http.post<Supplier>(this.baseUrl+'Supplier',supplier);
  }
  deleteSupplier(id:number):Observable<Supplier>{
    return this.http.delete<Supplier>(this.baseUrl+'Supplier/'+id);
  }
}
